DELETE FROM public.user_roles WHERE role='staff' AND user_id NOT IN (SELECT id FROM auth.users WHERE lower(email)='muniprasad@gmail.com');
INSERT INTO public.user_roles(user_id, role) SELECT id,'staff' FROM auth.users WHERE lower(email)='muniprasad@gmail.com' ON CONFLICT DO NOTHING;
CREATE OR REPLACE FUNCTION public.claim_staff(_code text) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF auth.uid() IS NULL THEN RETURN false; END IF;
  IF lower(coalesce(auth.jwt()->>'email',''))<>'muniprasad@gmail.com' THEN RETURN false; END IF;
  INSERT INTO public.user_roles(user_id, role) VALUES (auth.uid(),'staff') ON CONFLICT DO NOTHING;
  RETURN true;
END $$;