CREATE FUNCTION public.place_order_on_campus(_pickup_time text, _items jsonb, _latitude double precision, _longitude double precision, _accuracy double precision) RETURNS public.orders LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _distance double precision;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Not signed in'; END IF;
  IF _latitude IS NULL OR _longitude IS NULL OR _accuracy IS NULL OR NOT (_latitude BETWEEN -90 AND 90) OR NOT (_longitude BETWEEN -180 AND 180) OR NOT (_accuracy BETWEEN 0 AND 200) THEN
    RAISE EXCEPTION 'Your location is not accurate enough. Enable precise location and try again.';
  END IF;
  _distance := 6371000 * 2 * asin(sqrt(least(1.0, power(sin(radians(_latitude - 14.166973) / 2), 2) + cos(radians(14.166973)) * cos(radians(_latitude)) * power(sin(radians(_longitude - 79.859812) / 2), 2))));
  IF _distance > 1000 THEN RAISE EXCEPTION 'Orders are available only within 1 km of the college canteen.'; END IF;
  RETURN public.place_order(_pickup_time, _items);
END;
$$;
REVOKE ALL ON FUNCTION public.place_order_on_campus(text, jsonb, double precision, double precision, double precision) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.place_order_on_campus(text, jsonb, double precision, double precision, double precision) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.place_order(text, jsonb) FROM PUBLIC, anon, authenticated;
COMMENT ON FUNCTION public.place_order(text, jsonb) IS 'Internal order calculator; call place_order_on_campus to enforce campus location. Browser-reported location is spoofable and does not prove physical presence.';