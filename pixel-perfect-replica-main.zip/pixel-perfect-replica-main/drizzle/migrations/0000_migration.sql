
create type public.app_role as enum ('student','staff');
create type public.order_status as enum ('Placed','Preparing','Ready','Collected');

create table public.profiles (
  id uuid primary key,
  full_name text,
  email text,
  roll_number text,
  created_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  role app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create policy "own roles" on public.user_roles for select to authenticated using (user_id = auth.uid());
create policy "own profile read" on public.profiles for select to authenticated using (id = auth.uid() or public.has_role(auth.uid(),'staff'));
create policy "own profile update" on public.profiles for update to authenticated using (id = auth.uid());
create policy "own profile insert" on public.profiles for insert to authenticated with check (id = auth.uid());

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, email, roll_number)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'), new.email, new.raw_user_meta_data->>'roll_number');
  insert into public.user_roles (user_id, role) values (new.id, 'student');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- staff access code (demo)
create or replace function public.claim_staff(_code text)
returns boolean language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return false; end if;
  if _code <> 'AUDISANKARA-STAFF' then return false; end if;
  insert into public.user_roles (user_id, role) values (auth.uid(), 'staff') on conflict do nothing;
  return true;
end $$;

create table public.menu_items (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null check (category in ('Breakfast','Lunch','Snacks','Beverages')),
  price numeric(10,2) not null check (price >= 0),
  image_url text,
  is_veg boolean not null default true,
  is_available boolean not null default true,
  prep_time_minutes integer not null default 10,
  created_at timestamptz not null default now()
);
grant select on public.menu_items to anon;
grant select, insert, update, delete on public.menu_items to authenticated;
grant all on public.menu_items to service_role;
alter table public.menu_items enable row level security;
create policy "menu public read" on public.menu_items for select to anon, authenticated using (true);
create policy "staff insert menu" on public.menu_items for insert to authenticated with check (public.has_role(auth.uid(),'staff'));
create policy "staff update menu" on public.menu_items for update to authenticated using (public.has_role(auth.uid(),'staff'));
create policy "staff delete menu" on public.menu_items for delete to authenticated using (public.has_role(auth.uid(),'staff'));

create sequence public.order_number_seq start 101;
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique default ('AK-' || nextval('public.order_number_seq')),
  student_id uuid not null references public.profiles(id) on delete cascade,
  pickup_time text not null,
  total_amount numeric(10,2) not null,
  status order_status not null default 'Placed',
  created_at timestamptz not null default now()
);
grant select, update on public.orders to authenticated;
grant all on public.orders to service_role;
alter table public.orders enable row level security;
create policy "orders read" on public.orders for select to authenticated using (student_id = auth.uid() or public.has_role(auth.uid(),'staff'));
create policy "staff update orders" on public.orders for update to authenticated using (public.has_role(auth.uid(),'staff'));

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  item_id uuid references public.menu_items(id) on delete set null,
  item_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price numeric(10,2) not null
);
grant select on public.order_items to authenticated;
grant all on public.order_items to service_role;
alter table public.order_items enable row level security;
create policy "order items read" on public.order_items for select to authenticated using (
  exists (select 1 from public.orders o where o.id = order_id and (o.student_id = auth.uid() or public.has_role(auth.uid(),'staff')))
);

create or replace function public.place_order(_pickup_time text, _items jsonb)
returns public.orders language plpgsql security definer set search_path = public as $$
declare
  _order public.orders;
  _total numeric := 0;
  _it jsonb;
  _m public.menu_items;
  _q int;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if jsonb_array_length(_items) = 0 then raise exception 'Cart is empty'; end if;
  if length(coalesce(_pickup_time,'')) = 0 or length(_pickup_time) > 60 then raise exception 'Invalid pickup time'; end if;
  for _it in select * from jsonb_array_elements(_items) loop
    _q := (_it->>'quantity')::int;
    if _q is null or _q < 1 or _q > 20 then raise exception 'Invalid quantity'; end if;
    select * into _m from public.menu_items where id = (_it->>'item_id')::uuid;
    if not found or not _m.is_available then raise exception '% is sold out', coalesce(_m.name,'An item'); end if;
    _total := _total + _m.price * _q;
  end loop;
  insert into public.orders (student_id, pickup_time, total_amount) values (auth.uid(), _pickup_time, _total) returning * into _order;
  for _it in select * from jsonb_array_elements(_items) loop
    select * into _m from public.menu_items where id = (_it->>'item_id')::uuid;
    insert into public.order_items (order_id, item_id, item_name, quantity, unit_price)
    values (_order.id, _m.id, _m.name, (_it->>'quantity')::int, _m.price);
  end loop;
  return _order;
end $$;
revoke execute on function public.place_order(text, jsonb) from anon;

alter publication supabase_realtime add table public.orders;
alter publication supabase_realtime add table public.menu_items;
alter table public.orders replica identity full;

insert into public.menu_items (name, category, price, image_url, is_veg, prep_time_minutes) values
('Masala Dosa','Breakfast',50,'/images/breakfast.jpg',true,8),
('Idli Vada Combo','Breakfast',40,'/images/breakfast.jpg',true,5),
('Egg Omelette Toast','Breakfast',45,'/images/breakfast.jpg',false,7),
('South Indian Veg Meals','Lunch',80,'/images/lunch.jpg',true,5),
('Chicken Biryani','Lunch',120,'/images/lunch.jpg',false,10),
('Veg Fried Rice','Lunch',70,'/images/lunch.jpg',true,10),
('Samosa (2 pcs)','Snacks',20,'/images/snacks.jpg',true,3),
('Chicken Puff','Snacks',30,'/images/snacks.jpg',false,3),
('Mirchi Bajji','Snacks',25,'/images/snacks.jpg',true,5),
('Masala Chai','Beverages',15,'/images/beverages.jpg',true,2),
('Filter Coffee','Beverages',20,'/images/beverages.jpg',true,2),
('Fresh Lime Soda','Beverages',30,'/images/beverages.jpg',true,3);
