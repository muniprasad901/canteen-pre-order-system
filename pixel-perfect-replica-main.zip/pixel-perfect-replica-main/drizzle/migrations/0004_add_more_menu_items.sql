-- Add 12 more menu items; each keeps a legacy category image_url that the
-- menuImage() helper resolves to its own per-dish photo by name.
INSERT INTO public.menu_items (name, category, price, image_url, is_veg, is_available)
SELECT v.name, v.category, v.price, v.image_url, v.is_veg, true
FROM (VALUES
  ('Poori Masala', 'Breakfast', 35.00, '/images/breakfast.jpg', true),
  ('Ven Pongal', 'Breakfast', 40.00, '/images/breakfast.jpg', true),
  ('Rava Upma', 'Breakfast', 30.00, '/images/breakfast.jpg', true),
  ('Curd Rice', 'Lunch', 50.00, '/images/lunch.jpg', true),
  ('Egg Fried Rice', 'Lunch', 85.00, '/images/lunch.jpg', false),
  ('Paneer Butter Masala with Chapati', 'Lunch', 95.00, '/images/lunch.jpg', true),
  ('Chicken Fried Rice', 'Lunch', 100.00, '/images/lunch.jpg', false),
  ('Veg Puff', 'Snacks', 20.00, '/images/snacks.jpg', true),
  ('Gulab Jamun (2 pcs)', 'Snacks', 25.00, '/images/snacks.jpg', true),
  ('Chicken 65', 'Snacks', 75.00, '/images/snacks.jpg', false),
  ('Cold Coffee', 'Beverages', 35.00, '/images/beverages.jpg', true),
  ('Badam Milk', 'Beverages', 20.00, '/images/beverages.jpg', true)
) AS v(name, category, price, image_url, is_veg)
WHERE NOT EXISTS (
  SELECT 1 FROM public.menu_items m WHERE m.name = v.name
);