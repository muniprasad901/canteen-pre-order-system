import { useEffect, useState, type ImgHTMLAttributes } from "react";
import { supabase } from "@/integrations/supabase/client";

export const FOOD_PHOTO_PREFIX = "storage://menu-food-photos/";
const cache = new Map<string, { url: string; expires: number }>();

export function FoodImage({ src, ...props }: ImgHTMLAttributes<HTMLImageElement>) {
  const [resolved, setResolved] = useState<{ source: string; url: string } | null>(null);
  const stored = typeof src === "string" && src.startsWith(FOOD_PHOTO_PREFIX);
  useEffect(() => {
    if (typeof src !== "string" || !src.startsWith(FOOD_PHOTO_PREFIX)) return;
    let cancelled = false;
    const load = async () => {
      const saved = cache.get(src);
      if (saved && saved.expires > Date.now()) {
        setResolved({ source: src, url: saved.url });
        return;
      }
      const { data } = await supabase.storage.from("menu-food-photos").createSignedUrl(src.slice(FOOD_PHOTO_PREFIX.length), 3600);
      if (!cancelled && data?.signedUrl) {
        cache.set(src, { url: data.signedUrl, expires: Date.now() + 3500_000 });
        setResolved({ source: src, url: data.signedUrl });
      }
    };
    void load();
    const timer = setInterval(() => { void load(); }, 3400_000);
    return () => { cancelled = true; clearInterval(timer); };
  }, [src]);
  const imageSrc = stored ? (resolved?.source === src ? resolved.url : undefined) : src;
  return <img {...props} src={imageSrc} />;
}