import { Link, useNavigate } from "@tanstack/react-router";
import logo from "@/assets/audisankara-logo.png.asset.json";
import { ShoppingBag, History, ChefHat, LogOut, LogIn } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useApp } from "@/lib/app-state";
import { supabase } from "@/integrations/supabase/client";

export function SiteHeader() {
  const { session, isStaff, count, setCartOpen } = useApp();
  const navigate = useNavigate();
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-secondary text-secondary-foreground">
      <div className="mx-auto grid max-w-6xl grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3">
        <Link to="/" className="flex min-w-0 items-center gap-3">
          <div className="grid h-12 w-12 shrink-0 place-items-center overflow-hidden rounded-xl bg-card p-1">
            <img src={logo.url} alt="Audisankara University logo" className="h-full w-full object-contain" />
          </div>
          <div className="min-w-0">
            <p className="truncate font-display text-sm font-extrabold tracking-tight sm:text-lg">AUDISANKARA (DEEMED TO BE UNIVERSITY)</p>
            <p className="truncate text-[10px] opacity-70 sm:text-xs">Declared under Section 3 of the UGC Act, 1956</p>
          </div>
        </Link>
        <nav className="flex shrink-0 items-center gap-1">
          {session && (
            <Button asChild variant="ghost" size="sm" className="hidden sm:inline-flex">
              <Link to="/orders"><History /> Orders</Link>
            </Button>
          )}
          {isStaff && (
            <Button asChild variant="ghost" size="sm">
              <Link to="/kitchen"><ChefHat /><span className="hidden sm:inline">Kitchen</span></Link>
            </Button>
          )}
          <Button size="sm" onClick={() => setCartOpen(true)} className="relative hidden md:inline-flex">
            <ShoppingBag /> Cart
            {count > 0 && <span className="ml-1 rounded-full bg-secondary px-1.5 text-xs text-secondary-foreground">{count}</span>}
          </Button>
          {session ? (
            <Button variant="ghost" size="icon" aria-label="Sign out" onClick={async () => { await supabase.auth.signOut(); navigate({ to: "/", replace: true }); }}>
              <LogOut />
            </Button>
          ) : (
            <>
              <Button asChild variant="ghost" size="sm"><Link to="/auth" search={{}}><LogIn /> Login</Link></Button>
            </>
          )}
        </nav>
      </div>
      {session && (
        <div className="flex border-t border-border/20 sm:hidden">
          <Link to="/" className="flex-1 py-2 text-center text-xs" activeProps={{ className: "text-primary font-semibold" }} activeOptions={{ exact: true }}>Menu</Link>
          <Link to="/orders" className="flex-1 py-2 text-center text-xs" activeProps={{ className: "text-primary font-semibold" }}>My Orders</Link>
        </div>
      )}
    </header>
  );
}
