import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Minus, Plus, ShoppingBag } from "lucide-react";
import { toast } from "sonner";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { rupee, useApp } from "@/lib/app-state";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { menuImage } from "@/lib/menu-images";
import { FoodImage } from "@/components/FoodImage";

export function CartDrawer() {
  const { cart, add, dec, total, count, clear, cartOpen, setCartOpen, session } = useApp();
  const [slot, setSlot] = useState("");
  const [busy, setBusy] = useState(false);
  const [checkingLocation, setCheckingLocation] = useState(false);
  const [locationError, setLocationError] = useState("");
  const navigate = useNavigate();

  async function checkout() {
    if (busy) return;
    if (!session) { setCartOpen(false); navigate({ to: "/auth" }); return; }
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(slot)) { toast.error("Choose a pickup time"); return; }
    const hours = Number(slot.slice(0, 2));
    const minutes = Number(slot.slice(3, 5));
    const pickupTime = `${hours % 12 || 12}:${String(minutes).padStart(2, "0")} ${hours >= 12 ? "PM" : "AM"}`;
    setBusy(true);
    setLocationError("");
    setCheckingLocation(true);
    try {
    if (!navigator.geolocation) throw new Error("Location access is unavailable on this device.");
    const position = await new Promise<GeolocationPosition>((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, (error) => {
        reject(new Error(error.code === 1
          ? "Allow location access to order from the college."
          : "Could not find your location. Enable precise location and try again."));
      }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
    });
    setCheckingLocation(false);
    const { data, error } = await supabase.rpc("place_order_on_campus", {
      _pickup_time: pickupTime,
      _items: cart.map((l) => ({ item_id: l.item.id, quantity: l.quantity })),
      _latitude: position.coords.latitude,
      _longitude: position.coords.longitude,
      _accuracy: position.coords.accuracy,
    });
    if (error) throw new Error(error.message);
    if (!data) throw new Error("Could not place your order. Please try again.");
    clear();
    setSlot("");
    setCartOpen(false);
    toast.success(`Order #${(data as { order_number: string }).order_number} placed!`);
    navigate({ to: "/orders", search: { token: (data as { id: string }).id } });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Could not place your order. Please try again.";
      setLocationError(message);
      toast.error(message);
    } finally { setBusy(false); setCheckingLocation(false); }
  }

  return (
    <>
      {count > 0 && (
        <div className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-card p-3 md:hidden">
          <Button className="h-12 w-full justify-between text-base" onClick={() => setCartOpen(true)}>
            <span className="flex items-center gap-2"><ShoppingBag /> {count} item{count > 1 ? "s" : ""}</span>
            <span>{rupee(total)} · View cart</span>
          </Button>
        </div>
      )}
      <Sheet open={cartOpen} onOpenChange={setCartOpen}>
        <SheetContent className="flex w-full flex-col sm:max-w-md">
          <SheetHeader><SheetTitle className="font-display text-2xl">Your tray</SheetTitle></SheetHeader>
          <div className="flex-1 space-y-3 overflow-y-auto px-4">
            {cart.length === 0 && <p className="py-10 text-center text-muted-foreground">Your tray is empty. Add something tasty!</p>}
            {cart.map((l) => (
              <div key={l.item.id} className="flex items-center gap-3 rounded-xl border border-border p-2">
                <FoodImage src={menuImage(l.item)} alt={l.item.name} className="h-14 w-14 shrink-0 rounded-lg object-cover" />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">{l.item.name}</p>
                  <p className="text-sm text-muted-foreground">{rupee(l.item.price)} each</p>
                </div>
                <div className="flex items-center gap-1">
                  <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => dec(l.item.id)} aria-label="Remove one"><Minus /></Button>
                  <span className="w-6 text-center font-semibold">{l.quantity}</span>
                  <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => add(l.item)} aria-label="Add one"><Plus /></Button>
                </div>
              </div>
            ))}
          </div>
          {cart.length > 0 && (
            <div className="space-y-4 border-t border-border p-4">
              <div>
                <Label htmlFor="pickup-time" className="mb-2">Preferred pickup time</Label>
                <Input id="pickup-time" type="time" step={60} required value={slot} onChange={(e) => setSlot(e.target.value)} className="w-full min-w-0" />
              </div>
              <div className="flex items-center justify-between font-display text-xl font-bold">
                <span>Total</span><span>{rupee(total)}</span>
              </div>
              <Button className="h-12 w-full text-base" disabled={busy} onClick={checkout}>
                {session ? (checkingLocation ? "Checking location…" : busy ? "Placing…" : "Confirm order") : "Login to order"}
              </Button>
              {locationError && <p role="alert" className="text-sm text-destructive">{locationError}</p>}
            </div>
          )}
        </SheetContent>
      </Sheet>
    </>
  );
}
