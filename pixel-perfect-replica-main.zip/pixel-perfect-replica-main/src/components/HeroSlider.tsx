import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useApp } from "@/lib/app-state";
import { Button } from "@/components/ui/button";

const SLIDES = [
  { img: "/images/lunch.jpg", kicker: "Campus Canteen", title: "Skip the queue.", accent: "Enjoy your meal.", text: "Fresh campus favourites, collected with your token." },
  { img: "/images/breakfast.jpg", kicker: "Fresh every morning", title: "Hot dosas,", accent: "freshly made.", text: "Start your day with a delicious campus breakfast." },
  { img: "/images/beverages.jpg", kicker: "Campus favourites", title: "Chai & snacks", accent: "made for you.", text: "A warm cup and a tasty bite for your campus day." },
];

export function HeroSlider() {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const { setCartOpen } = useApp();
  useEffect(() => {
    if (paused) return;
    const t = setInterval(() => setI((n) => (n + 1) % SLIDES.length), 5000);
    return () => clearInterval(t);
  }, [paused]);
  const go = (d: number) => setI((n) => (n + d + SLIDES.length) % SLIDES.length);

  return (
    <section className="relative h-[420px] overflow-hidden bg-secondary text-secondary-foreground sm:h-[480px]"
      onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)} aria-roledescription="carousel">
      {SLIDES.map((s, k) => (
        <div key={k} className={`absolute inset-0 transition-opacity duration-1000 ${k === i ? "opacity-100" : "pointer-events-none opacity-0"}`} aria-hidden={k !== i}>
          <img src={s.img} alt="" width={944} height={704} loading={k === 0 ? "eager" : "lazy"}
            className={`absolute inset-0 h-full w-full object-cover transition-transform duration-[6000ms] ${k === i ? "scale-110" : "scale-100"}`} />
          <div className="absolute inset-0 bg-hero-overlay" />
          <div className="relative mx-auto flex h-full max-w-6xl flex-col justify-center px-4">
            <p className="mb-2 text-sm font-semibold uppercase tracking-widest text-primary">{s.kicker}</p>
            <h2 className="max-w-2xl text-4xl font-extrabold sm:text-6xl">{s.title} <span className="text-primary">{s.accent}</span></h2>
            <p className="mt-3 max-w-xl opacity-85">{s.text}</p>
            <div className="mt-6 flex gap-3">
              <Button size="lg" onClick={() => document.getElementById("menu")?.scrollIntoView({ behavior: "smooth" })}>Order now</Button>
              <Button size="lg" variant="outline" className="bg-transparent" onClick={() => setCartOpen(true)}>View tray</Button>
            </div>
          </div>
        </div>
      ))}
      <button onClick={() => go(-1)} aria-label="Previous slide" className="absolute left-3 top-1/2 hidden -translate-y-1/2 rounded-full bg-card/20 p-2 backdrop-blur sm:block"><ChevronLeft /></button>
      <button onClick={() => go(1)} aria-label="Next slide" className="absolute right-3 top-1/2 hidden -translate-y-1/2 rounded-full bg-card/20 p-2 backdrop-blur sm:block"><ChevronRight /></button>
      <div className="absolute bottom-5 left-1/2 flex -translate-x-1/2 gap-2">
        {SLIDES.map((_, k) => (
          <button key={k} onClick={() => setI(k)} aria-label={`Slide ${k + 1}`} className={`h-2 rounded-full transition-all ${k === i ? "w-8 bg-primary" : "w-2 bg-card/60"}`} />
        ))}
      </div>
    </section>
  );
}
