import coffee from "@/assets/filter-coffee.jpg";
import soda from "@/assets/fresh-lime-soda.jpg";
import chai from "@/assets/masala-chai.jpg";
import omelette from "@/assets/egg-omelette-toast.jpg";
import idli from "@/assets/idli-vada-combo.jpg";
import dosa from "@/assets/masala-dosa.jpg";
import biryani from "@/assets/chicken-biryani.jpg";
import meals from "@/assets/south-indian-veg-meals.jpg";
import rice from "@/assets/veg-fried-rice.jpg";
import puff from "@/assets/chicken-puff.jpg";
import bajji from "@/assets/mirchi-bajji.jpg";
import samosa from "@/assets/samosa.jpg";
import poori from "@/assets/poori-masala.jpg";
import pongal from "@/assets/ven-pongal.jpg";
import upma from "@/assets/rava-upma.jpg";
import curdRice from "@/assets/curd-rice.jpg";
import eggFriedRice from "@/assets/egg-fried-rice.jpg";
import paneer from "@/assets/paneer-butter-masala.jpg";
import chickenFriedRice from "@/assets/chicken-fried-rice.jpg";
import vegPuff from "@/assets/veg-puff.jpg";
import gulabJamun from "@/assets/gulab-jamun.jpg";
import chicken65 from "@/assets/chicken-65.jpg";
import coldCoffee from "@/assets/cold-coffee.jpg";
import badamMilk from "@/assets/badam-milk.jpg";

const photos: Record<string, string> = {
  "Filter Coffee": coffee,
  "Fresh Lime Soda": soda,
  "Masala Chai": chai,
  "Egg Omelette Toast": omelette,
  "Idli Vada Combo": idli,
  "Masala Dosa": dosa,
  "Chicken Biryani": biryani,
  "South Indian Veg Meals": meals,
  "Veg Fried Rice": rice,
  "Chicken Puff": puff,
  "Mirchi Bajji": bajji,
  "Samosa (2 pcs)": samosa,
  "Poori Masala": poori,
  "Ven Pongal": pongal,
  "Rava Upma": upma,
  "Curd Rice": curdRice,
  "Egg Fried Rice": eggFriedRice,
  "Paneer Butter Masala with Chapati": paneer,
  "Chicken Fried Rice": chickenFriedRice,
  "Veg Puff": vegPuff,
  "Gulab Jamun (2 pcs)": gulabJamun,
  "Chicken 65": chicken65,
  "Cold Coffee": coldCoffee,
  "Badam Milk": badamMilk,
};

/** Replace legacy category photos, while preserving staff-selected images. */
export function menuImage(item: { name: string; image_url: string | null }) {
  if (item.image_url && !/^\/images\/(breakfast|lunch|snacks|beverages)\.jpg$/.test(item.image_url)) {
    return item.image_url;
  }
  return photos[item.name] ?? item.image_url ?? "";
}
