import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type MenuItem = {
  id: string;
  name: string;
  category: string;
  price: number;
  image_url: string | null;
  is_veg: boolean;
  is_available: boolean;
  prep_time_minutes: number;
};
export type CartLine = { item: MenuItem; quantity: number };

type Ctx = {
  session: Session | null;
  isStaff: boolean;
  authReady: boolean;
  cart: CartLine[];
  add: (item: MenuItem) => void;
  dec: (id: string) => void;
  clear: () => void;
  count: number;
  total: number;
  cartOpen: boolean;
  setCartOpen: (o: boolean) => void;
};
const AppCtx = createContext<Ctx | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [isStaff, setIsStaff] = useState(false);
  const [authReady, setAuthReady] = useState(false);
  const [cart, setCart] = useState<CartLine[]>([]);
  const [cartOpen, setCartOpen] = useState(false);

  useEffect(() => {
    const raw = localStorage.getItem("ak-cart");
    if (raw) try { setCart(JSON.parse(raw)); } catch { /* ignore */ }
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setAuthReady(true); });
    return () => data.subscription.unsubscribe();
  }, []);

  useEffect(() => { localStorage.setItem("ak-cart", JSON.stringify(cart)); }, [cart]);

  useEffect(() => {
    if (!session) { setIsStaff(false); return; }
    supabase.from("user_roles").select("role").eq("user_id", session.user.id).then(({ data }) => {
      setIsStaff(!!data?.some((r) => r.role === "staff"));
    });
  }, [session]);

  const add = (item: MenuItem) =>
    setCart((c) => {
      const f = c.find((l) => l.item.id === item.id);
      return f ? c.map((l) => (l.item.id === item.id ? { ...l, quantity: Math.min(20, l.quantity + 1) } : l)) : [...c, { item, quantity: 1 }];
    });
  const dec = (id: string) =>
    setCart((c) => c.flatMap((l) => (l.item.id === id ? (l.quantity > 1 ? [{ ...l, quantity: l.quantity - 1 }] : []) : [l])));
  const count = cart.reduce((s, l) => s + l.quantity, 0);
  const total = cart.reduce((s, l) => s + l.quantity * Number(l.item.price), 0);

  return (
    <AppCtx.Provider value={{ session, isStaff, authReady, cart, add, dec, clear: () => setCart([]), count, total, cartOpen, setCartOpen, }}>
      {children}
    </AppCtx.Provider>
  );
}

export function useApp() {
  const c = useContext(AppCtx);
  if (!c) throw new Error("useApp outside provider");
  return c;
}

export const rupee = (n: number) => `₹${Number(n).toFixed(0)}`;

export const STATUS_CLASS: Record<string, string> = {
  Placed: "pill pill-placed",
  Preparing: "pill pill-preparing",
  Ready: "pill pill-ready",
  Collected: "pill pill-collected",
};
export const STATUS_LABEL: Record<string, string> = {
  Placed: "Placed",
  Preparing: "Preparing",
  Ready: "Ready for Pickup",
  Collected: "Collected",
};
