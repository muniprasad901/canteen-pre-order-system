import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { HeroSlider } from "@/components/HeroSlider";
import { menuImage } from "@/lib/menu-images";
import { FoodImage } from "@/components/FoodImage";
import { rupee, useApp, type MenuItem } from "@/lib/app-state";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Today's Menu — Audisankara Canteen Pre-Order" },
      { name: "description", content: "Skip the canteen queue. Browse today's menu, pre-order and pick up at your break." },
      { property: "og:title", content: "Today's Menu — Audisankara Canteen Pre-Order" },
      { property: "og:description", content: "Skip the canteen queue. Pre-order your meal and pick it up at your break." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MenuPage,
});

const CATS = ["All", "Breakfast", "Lunch", "Snacks", "Beverages"];

function MenuPage() {
  const [items, setItems] = useState<MenuItem[] | null>(null);
  const [cat, setCat] = useState("All");
  const [diet, setDiet] = useState<"all" | "veg" | "nonveg">("all");
  const { add, cart } = useApp();

  useEffect(() => {
    const load = () => supabase.from("menu_items").select("*").order("category").order("name").then(({ data }) => setItems((data as MenuItem[]) ?? []));
    load();
    const ch = supabase.channel("menu-live").on("postgres_changes", { event: "*", schema: "public", table: "menu_items" }, load).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  const shown = (items ?? []).filter((i) => (cat === "All" || i.category === cat) && (diet === "all" || (diet === "veg" ? i.is_veg : !i.is_veg)));

  return (
    <div className="pb-24">
      <HeroSlider />

      <div className="sticky top-[68px] z-20 border-b border-border bg-background/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl gap-2 overflow-x-auto px-4 py-3">
          {CATS.map((c) => (
            <Button key={c} size="sm" variant={cat === c ? "secondary" : "outline"} onClick={() => setCat(c)} className="rounded-full">{c}</Button>
          ))}
          <div className="mx-1 w-px shrink-0 bg-border" />
          {(["all", "veg", "nonveg"] as const).map((d) => (
            <Button key={d} size="sm" variant={diet === d ? "secondary" : "outline"} onClick={() => setDiet(d)} className="rounded-full">
              {d === "all" ? "All" : d === "veg" ? "🟢 Veg" : "🔴 Non-Veg"}
            </Button>
          ))}
        </div>
      </div>

      <div id="menu" className="mx-auto grid max-w-6xl scroll-mt-32 gap-5 px-4 py-6 sm:grid-cols-2 lg:grid-cols-3">
        {items === null && Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-72 animate-pulse rounded-2xl bg-muted" />)}
        {shown.map((item) => {
          const inCart = cart.find((l) => l.item.id === item.id)?.quantity;
          return (
            <article key={item.id} className="overflow-hidden rounded-2xl border border-secondary/20 bg-card shadow-card">
              <div className="relative">
                <FoodImage src={menuImage(item)} alt={item.name} loading="lazy" width={640} height={640}
                  className={`aspect-[4/3] w-full object-cover ${item.is_available ? "" : "grayscale opacity-60"}`} />
                {!item.is_available && <span className="absolute left-3 top-3 pill bg-destructive text-destructive-foreground">Sold Out</span>}
                <span className="absolute right-3 top-3 rounded-full bg-card px-3 py-1 font-display text-lg font-bold">{rupee(item.price)}</span>
              </div>
              <div className="flex items-end justify-between gap-3 p-4">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className={`h-3 w-3 shrink-0 rounded-sm border-2 ${item.is_veg ? "border-veg" : "border-nonveg"} p-[1px]`}>
                      <span className={`block h-full w-full rounded-full ${item.is_veg ? "bg-veg" : "bg-nonveg"}`} />
                    </span>
                    <h3 className="truncate text-lg font-bold">{item.name}</h3>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">{item.category}</p>
                </div>
                <Button disabled={!item.is_available} onClick={() => add(item)} className="shrink-0">
                  <Plus /> {inCart ? `Add (${inCart})` : "Add"}
                </Button>
              </div>
            </article>
          );
        })}
        {items && shown.length === 0 && <p className="col-span-full py-10 text-center text-muted-foreground">Nothing here right now.</p>}
      </div>
    </div>
  );
}
