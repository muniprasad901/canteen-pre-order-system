import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { QRCodeSVG } from "qrcode.react";
import { Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { rupee, STATUS_CLASS, STATUS_LABEL } from "@/lib/app-state";

type Order = {
  id: string; order_number: string; pickup_time: string; total_amount: number; status: string; created_at: string;
  order_items: { item_name: string; quantity: number }[];
};

export const Route = createFileRoute("/_authenticated/orders")({
  validateSearch: (s: Record<string, unknown>): { token?: string } => (typeof s["token"] === "string" ? { token: s["token"] } : {}),
  head: () => ({
    meta: [
      { title: "My Orders & Tokens — Audisankara Canteen" },
      { name: "description", content: "Track your canteen orders live and show your pickup token." },
      { property: "og:title", content: "My Orders — Audisankara Canteen" },
      { property: "og:description", content: "Live order tracking and digital pickup tokens." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: OrdersPage,
});

const STEPS = ["Placed", "Preparing", "Ready", "Collected"];

function OrdersPage() {
  const { token } = Route.useSearch();
  const [orders, setOrders] = useState<Order[] | null>(null);

  useEffect(() => {
    const load = async () => {
      const { data: u } = await supabase.auth.getUser();
      const { data } = await supabase.from("orders").select("*, order_items(item_name, quantity)")
        .eq("student_id", u.user!.id).order("created_at", { ascending: false }).limit(30);
      setOrders((data as Order[]) ?? []);
    };
    load();
    const ch = supabase.channel("my-orders").on("postgres_changes", { event: "*", schema: "public", table: "orders" }, load).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  const active = orders?.filter((o) => o.status !== "Collected") ?? [];
  const past = orders?.filter((o) => o.status === "Collected") ?? [];

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 pb-24">
      <h1 className="mb-6 text-3xl font-extrabold">My orders</h1>
      {orders === null && <div className="h-64 animate-pulse rounded-2xl bg-muted" />}
      {orders?.length === 0 && <p className="text-muted-foreground">No orders yet.</p>}
      <div className="space-y-5">
        {active.map((o) => (
          <div key={o.id} className={`overflow-hidden rounded-2xl border-2 bg-card shadow-card ${o.id === token ? "border-primary" : "border-secondary/20"}`}>
            <div className="grid gap-5 p-5 sm:grid-cols-[auto_1fr]">
              <div className="flex flex-col items-center rounded-xl bg-secondary p-4 text-secondary-foreground">
                <div className="rounded-lg bg-card p-2"><QRCodeSVG value={`AK:${o.order_number}:${o.id}`} size={120} /></div>
                <p className="mt-2 text-xs uppercase tracking-widest opacity-70">Token</p>
                <p className="font-display text-3xl font-extrabold text-primary">#{o.order_number}</p>
              </div>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className={STATUS_CLASS[o.status]}>{STATUS_LABEL[o.status]}</span>
                  <span className="font-display text-xl font-bold">{rupee(o.total_amount)}</span>
                </div>
                <p className="mt-2 text-sm text-muted-foreground">Pickup: <b className="text-foreground">{o.pickup_time}</b></p>
                <ul className="mt-2 text-sm">{o.order_items.map((i, k) => <li key={k}>{i.quantity} × {i.item_name}</li>)}</ul>
                <ol className="mt-4 flex items-center gap-1">
                  {STEPS.map((s, i) => {
                    const done = STEPS.indexOf(o.status) >= i;
                    return (
                      <li key={s} className="flex flex-1 flex-col items-center gap-1">
                        <span className={`grid h-6 w-6 place-items-center rounded-full text-xs ${done ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>{done ? <Check className="h-3 w-3" /> : i + 1}</span>
                        <span className="text-[10px] text-muted-foreground">{s}</span>
                      </li>
                    );
                  })}
                </ol>
              </div>
            </div>
          </div>
        ))}
      </div>
      {past.length > 0 && (
        <>
          <h2 className="mb-3 mt-10 text-xl font-bold">History</h2>
          <div className="divide-y divide-border rounded-2xl border border-border bg-card">
            {past.map((o) => (
              <div key={o.id} className="flex items-center justify-between gap-3 p-4 text-sm">
                <div className="min-w-0">
                  <p className="font-semibold">#{o.order_number} · {new Date(o.created_at).toLocaleDateString()}</p>
                  <p className="truncate text-muted-foreground">{o.order_items.map((i) => `${i.quantity}× ${i.item_name}`).join(", ")}</p>
                </div>
                <span className="shrink-0 font-semibold">{rupee(o.total_amount)}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
