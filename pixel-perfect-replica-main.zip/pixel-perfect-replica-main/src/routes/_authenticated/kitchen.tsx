import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { RefreshCw, Pencil, Trash2, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { menuImage } from "@/lib/menu-images";
import { FoodImage, FOOD_PHOTO_PREFIX } from "@/components/FoodImage";
import { rupee, STATUS_CLASS, STATUS_LABEL, useApp, type MenuItem } from "@/lib/app-state";

type Order = {
  id: string; order_number: string; pickup_time: string; total_amount: number; status: "Placed" | "Preparing" | "Ready" | "Collected"; created_at: string;
  profiles: { full_name: string | null; roll_number: string | null } | null;
  order_items: { item_name: string; quantity: number }[];
};

export const Route = createFileRoute("/_authenticated/kitchen")({
  head: () => ({
    meta: [
      { title: "Kitchen Display — Audisankara Canteen" },
      { name: "description", content: "Staff kitchen display: live order queue, menu availability and daily summary." },
      { property: "og:title", content: "Kitchen Display — Audisankara Canteen" },
      { property: "og:description", content: "Live order queue and menu manager for canteen staff." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Kitchen,
});

const NEXT: Record<string, { to: Order["status"]; label: string } | undefined> = {
  Placed: { to: "Preparing", label: "Mark as Preparing" },
  Preparing: { to: "Ready", label: "Mark as Ready" },
  Ready: { to: "Collected", label: "Mark Collected" },
};
const slotRank = (s: string) => {
  const match = s.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
  if (!match) return Infinity;
  let hours = Number(match[1]);
  if (match[3]) hours = hours % 12 + (match[3].toUpperCase() === "PM" ? 12 : 0);
  return hours * 60 + Number(match[2]);
};

function Kitchen() {
  const { isStaff, authReady } = useApp();
  const [orders, setOrders] = useState<Order[]>([]);
  const [menu, setMenu] = useState<MenuItem[]>([]);

  const loadOrders = async () => {
    const start = new Date(); start.setHours(0, 0, 0, 0);
    const { data: o } = await supabase.from("orders").select("*, order_items(item_name, quantity)")
      .gte("created_at", start.toISOString()).order("created_at");
    const ids = [...new Set((o ?? []).map((x) => x.student_id))];
    const { data: p } = ids.length ? await supabase.from("profiles").select("id, full_name, roll_number").in("id", ids) : { data: [] };
    setOrders((o ?? []).map((x) => ({ ...x, profiles: p?.find((pp) => pp.id === x.student_id) ?? null })) as Order[]);
  };
  const loadMenu = async () => {
    const { data } = await supabase.from("menu_items").select("*").order("category").order("name");
    setMenu((data as MenuItem[]) ?? []);
  };

  useEffect(() => {
    if (!isStaff) return;
    loadOrders(); loadMenu();
    const ch = supabase.channel("kds")
      .on("postgres_changes", { event: "*", schema: "public", table: "orders" }, loadOrders)
      .on("postgres_changes", { event: "*", schema: "public", table: "menu_items" }, loadMenu)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [isStaff]);

  if (!authReady) return null;
  if (!isStaff) return (
    <div className="mx-auto max-w-md px-4 py-16 text-center">
      <h1 className="text-2xl font-bold">Staff only</h1>
      <p className="mt-2 text-muted-foreground">Login on the Staff tab with your staff access code to open the kitchen display.</p>
      <Button asChild className="mt-4"><Link to="/auth" search={{ role: "staff" }}>Go to staff login</Link></Button>
    </div>
  );

  async function advance(o: Order) {
    const n = NEXT[o.status]; if (!n) return;
    setOrders((os) => os.map((x) => (x.id === o.id ? { ...x, status: n.to } : x)));
    const { error } = await supabase.from("orders").update({ status: n.to }).eq("id", o.id);
    if (error) { toast.error(error.message); loadOrders(); }
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 pb-24">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h1 className="text-3xl font-extrabold">Kitchen display</h1>
        <Button variant="outline" size="sm" onClick={() => { loadOrders(); loadMenu(); }}><RefreshCw /> Refresh</Button>
      </div>
      <Tabs defaultValue="queue">
        <TabsList><TabsTrigger value="queue">Live queue</TabsTrigger><TabsTrigger value="menu">Food items</TabsTrigger><TabsTrigger value="summary">Daily summary</TabsTrigger></TabsList>

        <TabsContent value="queue">
          <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {(["Placed", "Preparing", "Ready", "Collected"] as const).map((col) => {
              const list = orders.filter((o) => o.status === col).sort((a, b) => slotRank(a.pickup_time) - slotRank(b.pickup_time) || a.created_at.localeCompare(b.created_at));
              return (
                <section key={col} className="rounded-2xl bg-muted p-3">
                  <div className="mb-3 flex items-center justify-between"><span className={STATUS_CLASS[col]}>{STATUS_LABEL[col]}</span><span className="text-sm font-bold">{list.length}</span></div>
                  <div className="space-y-3">
                    {list.map((o) => (
                      <article key={o.id} className="rounded-xl border border-secondary/20 bg-card p-3 shadow-card">
                        <div className="flex items-center justify-between"><span className="font-display text-xl font-extrabold">#{o.order_number}</span><span className="text-xs font-semibold text-muted-foreground">{o.pickup_time}</span></div>
                        <p className="text-xs text-muted-foreground">{o.profiles?.full_name ?? "Student"}{o.profiles?.roll_number ? ` · ${o.profiles.roll_number}` : ""}</p>
                        <ul className="my-2 text-sm">{o.order_items.map((i, k) => <li key={k}><b>{i.quantity}×</b> {i.item_name}</li>)}</ul>
                        {NEXT[o.status] && <Button size="sm" className="w-full" variant={o.status === "Ready" ? "secondary" : "default"} onClick={() => advance(o)}>{NEXT[o.status]?.label}</Button>}
                      </article>
                    ))}
                    {list.length === 0 && <p className="py-4 text-center text-xs text-muted-foreground">Empty</p>}
                  </div>
                </section>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="menu"><MenuManager menu={menu} onChange={loadMenu} /></TabsContent>
        <TabsContent value="summary"><Summary orders={orders} /></TabsContent>
      </Tabs>
    </div>
  );
}

const EMPTY = { name: "", category: "Snacks", price: "", image_url: "", is_veg: true };
function MenuManager({ menu, onChange }: { menu: MenuItem[]; onChange: () => void }) {
  const [f, setF] = useState(EMPTY);
  const [editId, setEditId] = useState<string | null>(null);
  const [photo, setPhoto] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [saving, setSaving] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (!photo) { setPreview(""); return; }
    const url = URL.createObjectURL(photo);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [photo]);
  function resetPhoto() {
    setPhoto(null);
    if (fileInput.current) fileInput.current.value = "";
  }
  function choosePhoto(file: File | undefined) {
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp", "image/gif"].includes(file.type)) {
      toast.error("Choose a JPG, PNG, WebP or GIF photo"); return;
    }
    if (file.size > 5 * 1024 * 1024) { toast.error("Photo must be smaller than 5 MB"); return; }
    setPhoto(file);
  }
  async function toggle(m: MenuItem, v: boolean) {
    const { error } = await supabase.from("menu_items").update({ is_available: v }).eq("id", m.id);
    if (error) toast.error(error.message); else onChange();
  }
  function startEdit(m: MenuItem) {
    resetPhoto();
    setEditId(m.id);
    setF({ name: m.name, category: m.category, price: String(m.price), image_url: m.image_url ?? "", is_veg: m.is_veg });
  }
  async function remove(m: MenuItem) {
    if (!confirm(`Delete "${m.name}" from the menu?`)) return;
    const { error } = await supabase.from("menu_items").delete().eq("id", m.id);
    if (error) { toast.error(error.message); return; }
    toast.success("Item deleted"); if (editId === m.id) { setEditId(null); setF(EMPTY); resetPhoto(); } onChange();
  }
  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (saving) return;
    const price = Number(f.price);
    if (!f.name.trim() || f.price === "" || !(price >= 0)) { toast.error("Enter a name and price"); return; }
    setSaving(true);
    let uploadedPath: string | null = null;
    try {
    let imageUrl = f.image_url.trim();
    if (photo) {
      const extension = ({ "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/gif": "gif" } as Record<string, string>)[photo.type];
      uploadedPath = `${crypto.randomUUID()}.${extension}`;
      const { error } = await supabase.storage.from("menu-food-photos").upload(uploadedPath, photo, { contentType: photo.type });
      if (error) throw error;
      imageUrl = `${FOOD_PHOTO_PREFIX}${uploadedPath}`;
    }
    const row = {
      name: f.name.trim().slice(0, 80), category: f.category, price, is_veg: f.is_veg,
      image_url: imageUrl || `/images/${f.category.toLowerCase()}.jpg`,
    };
    const { error } = editId
      ? await supabase.from("menu_items").update(row).eq("id", editId)
      : await supabase.from("menu_items").insert(row);
    if (error) throw error;
    toast.success(editId ? "Item updated" : "Item added"); setEditId(null); setF(EMPTY); resetPhoto(); onChange();
    } catch (error) {
      if (uploadedPath) await supabase.storage.from("menu-food-photos").remove([uploadedPath]);
      toast.error(error instanceof Error ? error.message : "Could not save the food item. Please try again.");
    } finally { setSaving(false); }
  }
  return (
    <div className="mt-4 grid gap-6 lg:grid-cols-[1fr_340px]">
      <div className="divide-y divide-border rounded-2xl border border-border bg-card">
        {menu.map((m) => (
          <div key={m.id} className={`flex flex-wrap items-center gap-3 p-3 ${editId === m.id ? "bg-accent" : ""}`}>
            <FoodImage src={menuImage(m)} alt={m.name} className="h-12 w-12 shrink-0 rounded-lg object-cover" />
            <div className="min-w-0 flex-1"><p className="truncate font-medium">{m.name}</p><p className="text-xs text-muted-foreground">{m.category} · {rupee(m.price)} · {m.is_veg ? "Veg" : "Non-Veg"}</p></div>
            <div className="flex items-center gap-2">
              <span className={`w-16 text-right text-xs font-semibold ${m.is_available ? "text-status-ready" : "text-destructive"}`}>{m.is_available ? "Open" : "Closed"}</span>
              <Switch checked={m.is_available} onCheckedChange={(v) => toggle(m, v)} aria-label="Open or close item" />
              <Button size="icon" variant="ghost" onClick={() => startEdit(m)} aria-label="Edit"><Pencil /></Button>
              <Button size="icon" variant="ghost" onClick={() => remove(m)} aria-label="Delete" className="text-destructive"><Trash2 /></Button>
            </div>
          </div>
        ))}
        {menu.length === 0 && <p className="p-6 text-center text-sm text-muted-foreground">No food items yet.</p>}
      </div>
      <form onSubmit={save} className="h-fit space-y-3 rounded-2xl border border-border bg-card p-4 shadow-card lg:sticky lg:top-24">
        <h2 className="text-lg font-bold">{editId ? "Edit food item" : "Add food item"}</h2>
        <fieldset disabled={saving} className="min-w-0 space-y-3">
        <div><Label>Name</Label><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
        <div><Label>Price (₹)</Label><Input type="number" min={0} value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })} /></div>
        <div><Label>Category</Label>
          <select className="h-9 w-full rounded-md border border-input bg-background px-2 text-sm" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>
            {["Breakfast", "Lunch", "Snacks", "Beverages"].map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="food-photo">Food photo</Label>
          <input ref={fileInput} id="food-photo" type="file" accept="image/jpeg,image/png,image/webp,image/gif" className="hidden" onChange={(e) => choosePhoto(e.target.files?.[0])} />
          {(preview || f.image_url) && <FoodImage src={preview || menuImage(f)} alt={f.name || "Food photo preview"} className="h-36 w-full rounded-lg object-cover" />}
          <div className="flex items-center gap-2">
            <Button type="button" variant="outline" className="min-w-0 flex-1" onClick={() => fileInput.current?.click()}><Upload /> {preview || f.image_url ? "Change photo" : "Upload photo"}</Button>
            {photo && <Button type="button" variant="ghost" size="icon" aria-label="Remove selected photo" onClick={resetPhoto}><X /></Button>}
          </div>
          {photo && <p className="truncate text-xs text-muted-foreground">{photo.name}</p>}
        </div>
        <label className="flex items-center gap-2 text-sm"><Switch checked={f.is_veg} onCheckedChange={(v) => setF({ ...f, is_veg: v })} /> Vegetarian</label>
        <div className="flex gap-2">
          <Button className="flex-1">{saving ? "Saving…" : editId ? "Save changes" : "Add to menu"}</Button>
          {editId && <Button type="button" variant="outline" onClick={() => { setEditId(null); setF(EMPTY); resetPhoto(); }}>Cancel</Button>}
        </div>
        </fieldset>
      </form>
    </div>
  );
}

function Summary({ orders }: { orders: Order[] }) {
  const { revenue, dishes } = useMemo(() => {
    const d: Record<string, number> = {};
    orders.forEach((o) => o.order_items.forEach((i) => { d[i.item_name] = (d[i.item_name] ?? 0) + i.quantity; }));
    return { revenue: orders.reduce((s, o) => s + Number(o.total_amount), 0), dishes: Object.entries(d).sort((a, b) => b[1] - a[1]) };
  }, [orders]);
  const max = dishes[0]?.[1] ?? 1;
  return (
    <div className="mt-4 space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="Orders today" value={String(orders.length)} />
        <Stat label="Revenue" value={rupee(revenue)} />
        <Stat label="Collected" value={String(orders.filter((o) => o.status === "Collected").length)} />
      </div>
      <div className="rounded-2xl border border-border bg-card p-5">
        <h2 className="mb-4 text-lg font-bold">Quantity demanded per dish</h2>
        {dishes.length === 0 && <p className="text-sm text-muted-foreground">No orders yet today.</p>}
        <div className="space-y-2">
          {dishes.map(([n, q]) => (
            <div key={n} className="grid grid-cols-[minmax(0,10rem)_1fr_3rem] items-center gap-3 text-sm">
              <span className="truncate">{n}</span>
              <div className="h-3 rounded-full bg-muted"><div className="h-3 rounded-full bg-primary" style={{ width: `${(q / max) * 100}%` }} /></div>
              <span className="text-right font-bold">{q}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
function Stat({ label, value }: { label: string; value: string }) {
  return <div className="rounded-2xl bg-secondary p-5 text-secondary-foreground"><p className="text-sm opacity-70">{label}</p><p className="font-display text-4xl font-extrabold text-primary">{value}</p></div>;
}
