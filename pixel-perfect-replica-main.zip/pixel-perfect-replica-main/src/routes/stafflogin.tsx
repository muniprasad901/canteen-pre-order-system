import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useApp } from "@/lib/app-state";

export const Route = createFileRoute("/stafflogin")({
  head: () => ({
    meta: [
      { title: "Staff Login — Audisankara Canteen" },
      { name: "description", content: "Canteen staff login." },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Staff Login — Audisankara Canteen" },
      { property: "og:description", content: "Canteen staff login." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: StaffLogin,
});

function StaffLogin() {
  const { session, isStaff } = useApp();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (session && isStaff) navigate({ to: "/kitchen" });
  }, [session, isStaff, navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) { toast.error(error.message); setBusy(false); return; }
    const { data: ok } = await supabase.rpc("has_role", { _user_id: data.user.id, _role: "staff" });
    if (!ok) {
      await supabase.auth.signOut();
      toast.error("This account is not the canteen staff account.");
      setBusy(false);
      return;
    }
    window.location.href = "/kitchen";
  }

  return (
    <div className="mx-auto max-w-md px-4 py-10">
      <div className="rounded-2xl border border-border bg-card p-6 shadow-card">
        <h1 className="text-3xl font-extrabold">Staff login</h1>
        <p className="mb-5 text-sm text-muted-foreground">Canteen staff portal</p>
        <form onSubmit={submit} className="space-y-3">
          <div><Label>Email</Label><Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
          <div><Label>Password</Label><Input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} /></div>
          <Button className="h-11 w-full" disabled={busy}>Login</Button>
        </form>
      </div>
    </div>
  );
}
