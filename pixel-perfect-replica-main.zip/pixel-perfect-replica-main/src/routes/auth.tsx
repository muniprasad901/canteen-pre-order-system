import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useApp } from "@/lib/app-state";

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): { role?: "staff" } => (s["role"] === "staff" ? { role: "staff" } : {}),
  head: () => ({
    meta: [
      { title: "Login — Audisankara Canteen" },
      { name: "description", content: "Student and staff login for the Audisankara canteen pre-order system." },
      { property: "og:title", content: "Login — Audisankara Canteen" },
      { property: "og:description", content: "Student and staff login for the canteen pre-order system." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { session, isStaff } = useApp();
  const navigate = useNavigate();
  const search = Route.useSearch();
  const [role] = useState<"student" | "staff">("student");
  const [mode, setMode] = useState<"in" | "up">("in");
  const [f, setF] = useState({ email: "", password: "", name: "", roll: "", code: "" });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!session) return;
    if (role === "staff" && !isStaff && f.code) {
      supabase.rpc("claim_staff", { _code: f.code }).then(({ data }) => {
        if (data) { toast.success("Staff access granted"); window.location.href = "/kitchen"; }
        else toast.error("Invalid staff access code");
      });
      return;
    }
    navigate({ to: role === "staff" || isStaff ? "/kitchen" : "/" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, isStaff]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    if (mode === "up") {
      const { data, error } = await supabase.auth.signUp({
        email: f.email, password: f.password,
        options: { emailRedirectTo: window.location.origin, data: { full_name: f.name, roll_number: f.roll } },
      });
      if (error) toast.error(error.message);
      else if (!data.session) toast.success("Check your email to confirm your account.");
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email: f.email, password: f.password });
      if (error) toast.error(error.message);
    }
    setBusy(false);
  }

  async function google() {
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/auth" });
    if (r.error) toast.error(r.error.message);
  }

  return (
    <div className="mx-auto max-w-md px-4 py-10">
      <div className="rounded-2xl border border-border bg-card p-6 shadow-card">
        <h1 className="text-3xl font-extrabold">{mode === "in" ? "Welcome back" : "Create account"}</h1>
        <p className="mb-5 text-sm text-muted-foreground">{role === "staff" ? "Canteen staff portal" : "Order ahead, skip the line"}</p>
        <form onSubmit={submit} className="space-y-3">
          {mode === "up" && (
            <>
              <div><Label>Full name</Label><Input required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
              {role === "student" && <div><Label>Roll number</Label><Input value={f.roll} onChange={(e) => setF({ ...f, roll: e.target.value })} /></div>}
            </>
          )}
          <div><Label>Email</Label><Input type="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
          <div><Label>Password</Label><Input type="password" required minLength={6} value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></div>
          {role === "staff" && (
            <div><Label>Staff access code</Label><Input value={f.code} placeholder="Only needed the first time" onChange={(e) => setF({ ...f, code: e.target.value })} /></div>
          )}
          <Button className="h-11 w-full" disabled={busy}>{mode === "in" ? "Login" : "Sign up"}</Button>
        </form>
        <Button variant="outline" className="mt-3 h-11 w-full" onClick={google}>Continue with Google</Button>
        <button className="mt-4 w-full text-center text-sm text-muted-foreground underline" onClick={() => setMode(mode === "in" ? "up" : "in")}>
          {mode === "in" ? "New here? Create an account" : "Already have an account? Login"}
        </button>
      </div>
    </div>
  );
}
