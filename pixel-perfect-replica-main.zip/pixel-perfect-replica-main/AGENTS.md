<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Canteen app data access goes through the browser Supabase client with RLS; order placement uses `place_order_on_campus`, which validates reported location then calls the internal `place_order` price/availability calculator; direct client execution of `place_order` is revoked to prevent bypassing the location check.
- Staff role lives in `user_roles` (checked via `has_role`); staff is granted only via the `claim_staff` RPC access code.
- Resolve legacy category images through the shared menu-image helper across menu, cart, and staff views; preserve staff-provided image URLs so photo edits remain authoritative.
- Capture pickup time with a minute-precision time input and pass a readable time to the campus order RPC; rank kitchen orders by parsed clock time to support both new selections and legacy orders.
- Request fresh high-accuracy browser geolocation only at checkout and enforce distance and accuracy in the campus RPC; browser location can be spoofed, so never describe this as proof of physical presence.
- Store device food photos in the private menu-food-photos bucket with public read and staff-only writes enforced by storage RLS; persist storage references and resolve expiring signed URLs through FoodImage in menu, cart, and kitchen.
